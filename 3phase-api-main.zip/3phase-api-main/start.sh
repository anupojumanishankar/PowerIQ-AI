#!/bin/bash
set -e

# Start MongoDB
mongod --fork --logpath /var/log/mongodb.log --dbpath /data/db

# Start mongo-express in background
mongo-express &

# Start Node.js app in foreground
npm start