const Data = require("../models/DataIot");

exports.storeData = async (req, res) => {
  const { deviceId, data } = req.body;
  try {
    const newData = new Data({ deviceId, data });
    await newData.save();
    res.status(201).json({ message: "Data stored successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getData = async (req, res) => {
  const { deviceId } = req.params;
  try {
    const data = await Data.find({ deviceId }).sort({ timestamp: -1 });
    res.json(data);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
