// const Device = require("../models/Device");
const User = require("../models/User"); // Assuming you have a User model
const Machine = require("../models/Machine");
const Notification = require("../models/Notification");

// Get All Devices
exports.getAllDevices = async (req, res) => {
  try {
    const devices = await Machine.find().populate(
      "company",
      "name address image"
    );

    res.status(200).json(devices);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get All Company Devices
exports.getAllMyCompanyDevices = async (req, res) => {
  try {
    // Extract current user ID from the request (assumes authentication middleware is used)
    const userId = req.user.id;

    console.log(userId);

    // Find the user's company ID
    const user = await User.findById(userId).select("company");
    if (!user || !user.company) {
      return res.status(404).json({ message: "User or company not found" });
    }

    const companyId = user.company;

    console.log(companyId);

    // Fetch all devices linked to the user's company
    const devices = await Machine.find({ company: companyId });
    // .select(
    //   "name address isActive image deviceId data_interval"
    // );
    // .populate(
    //   "company",
    //   "name address image"
    // );

    res.status(200).json(devices);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Create a Device
exports.createDevice = async (req, res) => {
  try {
    const {
      name,
      label,
      deviceId,
      token,
      company: requestCompany,
      tbAccount,
    } = req.body;
    const image = req.file ? req.file.filename : null;

    let company = requestCompany;

    // if (!company) {
    //   const userId = req.user.id;

    //   // console.log(userId);

    //   // Find the user's company ID
    //   // const user = await User.findById(userId); //.select("company");
    //   // console.log(user);

    //   // if (!user || !user.company) {
    //   //   return res.status(404).json({ message: "User or company not found" });
    //   // }

    //   // company = user.company; // Assign the user's company ID
    //   // console.log(company);
    // }

    // Step 1: Create a Machine with default values
    const newMachine = await Machine.create({
      name,
      label,
      deviceId,
      token,
      make: "",
      model: "",
      std_current_rating: null,
      maximum_load: null,
      floating_current_R: null,
      floating_current_Y: null,
      floating_current_B: null,
      load_current_R: null,
      load_current_Y: null,
      load_current_B: null,
      // device: null, // Initially no linked device
      company,
      image: null,
      tbAccount,
    });

    // // Step 2: Create the Device and link it to the Machine
    // const newDevice = await Device.create({
    //   name,
    //   label,
    //   deviceId,
    //   token,
    //   image,
    //   company,
    //   machine: newMachine._id, // Link the Machine ID to the Device
    // });

    // // Step 3: Update the Machine with the Device's ID
    // newMachine.device = newDevice._id;
    // await newMachine.save();

    res.status(201).json({
      message: "Device and associated Machine created successfully",
      // device: newDevice,
      machine_device: newMachine,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get Device by ID
exports.getDeviceById = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const device = await Machine.findById(deviceId);

    if (!device) {
      return res.status(404).json({ message: "Device not found" });
    }

    res.status(200).json(device);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get Device by ID ESP
exports.getDeviceByIdESP = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const device = await Machine.findById(deviceId).select(
      "token data_interval"
    );

    if (!device) {
      return res.status(404).json({ message: "Device not found" });
    }

    res.status(200).json(device);
    // res.status(200).send(device.token);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Update a Device
exports.updateDevice = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const {
      name,
      label,
      token,
      isActive,
      make,
      model,
      std_current_rating,
      maximum_load,
      floating_current_R,
      floating_current_Y,
      floating_current_B,
      load_current_R,
      load_current_Y,
      load_current_B,
    } = req.body;

    const updateData = {
      name,
      label,
      token,
      isActive,
      make,
      model,
      std_current_rating,
      maximum_load,
      floating_current_R,
      floating_current_Y,
      floating_current_B,
      load_current_R,
      load_current_Y,
      load_current_B,
    };

    // Only include the image field if a file is uploaded
    if (req.file) {
      updateData.image = req.file.filename;
    }

    const updatedDevice = await Machine.findByIdAndUpdate(
      deviceId,
      updateData,
      { new: true, runValidators: true }
    );

    if (!updatedDevice) {
      return res.status(404).json({ message: "Device not found" });
    }

    res.status(200).json({
      message: "Device updated successfully",
      device: updatedDevice,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Link a Device with Company
exports.linkDeviceWithCompany = async (req, res) => {
  try {
    const { name, deviceId } = req.body;
    let company;

    const userId = req.user.id;

    if (!company) {
      // const userId = req.user.id;

      // Fetch the user's company
      const user = await User.findById(userId).select("company");

      if (!user || !user.company) {
        return res.status(404).json({ message: "User or company not found" });
      }

      company = user.company; // Assign the user's company ID
    }

    // Check if the device exists and is already linked
    const device = await Machine.findById(deviceId);
    if (!device) {
      return res.status(404).json({ message: "Device not found" });
    }

    if (device.company) {
      return res.status(400).json({
        message: "Device is already linked to a company",
        // linkedCompany: device.company, // Optional: Include the linked company info
      });
    }

    // Link the device to the user's company
    device.name = name;
    device.isActive = true;
    device.company = company;

    const updatedDevice = await device.save();

    // Notify the user or company admin
    const notification = {
      user: req.user.id, // ID of the user triggering the action
      title: "Device Linked Successfully",
      message: `The device ${name} has been successfully added.`,
      metadata: { deviceId: device._id }, // Include metadata if needed
      device: deviceId,
    };

    // Call the notification API or emit via Socket.io
    if (req.io) {
      // console.log(notification);
      // console.log("aaa - " + userId);

      req.io.to(userId).emit("newNotification", notification); // Emit to the user
    }

    // Save the notification to the database (if needed)
    await Notification.create(notification);

    res.status(200).json({
      message: "Device linked successfully and notification sent",
      device: updatedDevice,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Delete a Device
exports.deleteDevice = async (req, res) => {
  try {
    const { deviceId } = req.params;

    const deletedDevice = await Machine.findByIdAndDelete(deviceId);
    if (!deletedDevice) {
      return res.status(404).json({ message: "Device not found" });
    }

    res.status(200).json({ message: "Device deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};
