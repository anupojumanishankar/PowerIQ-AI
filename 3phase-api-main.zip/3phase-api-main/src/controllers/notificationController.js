// notificationController.js
const Notification = require("../models/Notification");
const Machine = require("../models/Machine");
const User = require("../models/User");
const { sendFCMNotification } = require("../services/notificationService");

// Get All Notifications
exports.getAllNotifications = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming you extract user info from authentication middleware
    const notifications = await Notification.find({ user: userId }).sort({
      createdAt: -1,
    });
    res.status(200).json(notifications);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get All Notifications by deviceId
exports.getAllNotificationsByDeviceId = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming user info is extracted from authentication middleware
    const deviceId = req.params.deviceId; // Get deviceId from route parameters
    console.log(deviceId);

    // Query to find notifications for the specific user and device
    const notifications = await Notification.find({
      user: userId,
      device: deviceId,
    }).sort({ createdAt: -1 });

    res.status(200).json(notifications);
  } catch (error) {
    console.error("Error fetching notifications:", error.message);
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Add a Notification
exports.addNotification = async (req, res) => {
  try {
    const { title, message, deviceId } = req.body;
    const userId = req.user.id;

    const newNotification = await Notification.create({
      title,
      message,
      user: userId,
      isRead: false,
      device: deviceId,
    });

    // Emit new notification to the user via sockets (optional)
    if (req.io) {
      req.io.to(userId).emit("newNotification", newNotification);
    }

    res.status(201).json({
      message: "Notification created successfully",
      notification: newNotification,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Add a Notification
exports.tbAddNotification = async (req, res) => {
  // // Send Firebase notification
  // await sendFCMNotification(
  //   "dKca3HqnR9iIQNP0KmSkKK:APA91bHnJw6I7qXGhGcibAWQRVr5WR2Khr0loabJkSG1lzIwanE4qwMFhw8UjxdQH6YuFaN0c2x_YqQ4skbDrrQIRmb_Avvf1y9fJ5wyavv_cVT9Ym8j298", // fcmToken,
  //   "New Echo Data",
  //   "Check your latest update!"
  // );

  try {
    const {
      V12,
      V23,
      V31,
      I1,
      I2,
      I3,
      PF1,
      PF2,
      PF3,
      Avg_PF,
      Frequency,
      Total_kWh,
      Total_kW,
      Total_kVAh,
      PF_Level,
      Machine_Status,
      Alert_Title,
      Alert_Description,
      deviceName,
      deviceId,
    } = req.body;

    const machine = await Machine.findOne({ deviceId: deviceId });
    if (!machine) {
      return res.status(404).json({ message: "Machine not found" });
    }
    const machineId = machine._id;
    const machineName = machine.name;

    // Get the companyId from the machine
    const companyId = machine.company;

    if (!companyId) {
      return res
        .status(400)
        .json({ message: "Machine has no associated company" });
    }

    // // Find users associated with this company
    // const users = await User.find({ company: companyId });

    // if (users.length === 0) {
    //   return res.status(404).json({ message: "No users found for this company" });
    // }

    // // Extract user IDs
    // const userIds = users.map(user => user._id);

    const user = await User.findOne({ company: companyId });
    if (!user) {
      return res
        .status(404)
        .json({ message: "No user found for this company" });
    }

    // console.info(machine, user);

    const userId = user._id;
    const tokan = user.tokan;

    title = machineName || "No Title";
    message = Alert_Description || "No Description";

    const newNotification = await Notification.create({
      title,
      message,
      isRead: false,
      device: machineId,
      company: companyId,
      user: userId,
    });

    // // Emit new notification to the user via sockets (optional)
    // if (req.io) {
    //   req.io.to(userId).emit("newNotification", newNotification);
    // }

    sendFCMNotification(tokan, title, message);

    res.status(201).json({
      message: "Notification created successfully",
      notification: newNotification,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Mark Notification as Read
exports.markNotificationAsRead = async (req, res) => {
  try {
    const { notificationId } = req.params;

    const notification = await Notification.findByIdAndUpdate(
      notificationId,
      { isRead: true },
      { new: true }
    );

    if (!notification) {
      return res.status(404).json({ message: "Notification not found" });
    }

    res.status(200).json({
      message: "Notification marked as read",
      notification,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};
