const Page = require("../models/Page");

exports.getAllPages = async (req, res) => {
  try {
    const pages = await Page.find();
    res.status(200).json(pages);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

exports.createPage = async (req, res) => {
  try {
    const { name, text } = req.body;
    const existingPage = await Page.findOne({ name });
    if (existingPage) {
      return res.status(400).json({ message: "Page name already in use" });
    }

    const newPage = await Page.create({ name, text });
    res
      .status(201)
      .json({ message: "Page created successfully", page: newPage });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

exports.getPageById = async (req, res) => {
  try {
    const { pageId } = req.params;
    console.log(pageId);

    const page = await Page.findOne({ name: pageId });
    if (!page) {
      return res.status(404).json({ message: "Page not found" });
    }
    res.status(200).json(page);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

exports.updatePage = async (req, res) => {
  try {
    const { pageId } = req.params;
    const { text } = req.body;

    // Build the update object dynamically
    const updateData = {
      text,
    };

    const updatedPage = await Page.findByIdAndUpdate(pageId, updateData, {
      new: true,
      runValidators: true,
    });

    if (!updatedPage) {
      return res.status(404).json({ message: "Page not found" });
    }

    res.status(200).json({
      message: "Page updated successfully",
      page: updatedPage,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

exports.deletePage = async (req, res) => {
  try {
    const { pageId } = req.params;

    const deletedPage = await Page.findByIdAndDelete(pageId);
    if (!deletedPage) {
      return res.status(404).json({ message: "Page not found" });
    }

    res.status(200).json({ message: "Page deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};
