const Machine = require("../models/Machine");
const axios = require("axios");

// ThingsBoard Configuration
const TB_URL = process.env.TB_URL || "https://thingsboard.cloud";

// Get all machines
exports.getDataTimeSeries = async (req, res) => {
  const { startTime, endTime, deviceId, userLimit } = req.body;

  console.log(startTime, endTime, deviceId, userLimit);

  if (!startTime || !endTime || !deviceId) {
    return res
      .status(400)
      .json({ message: "startTime, endTime, and deviceId are required" });
  }
  if (!userLimit) {
    userLimit = process.env.USER_LIMIT_RECORDS;
  }

  const deviceDetails = await Machine.findById(deviceId).populate(
    "tbAccount",
    "name token"
  );

  try {
    const tbToken = deviceDetails.tbAccount.token;

    if (!tbToken) {
      return res
        .status(401)
        .json({ message: "Authorization token for ThingsBoard is missing" });
    }

    // Construct the ThingsBoard API endpoint
    const thingsBoardApiUrl = `${TB_URL}/api/plugins/telemetry/DEVICE/${deviceDetails.deviceId}/values/timeseries?keys=I1,I2,I3,PF1,PF2,PF3,V12,V23,V31,Frequency,Total_kWh,Total_kW,Avg_PF,Total_kVAh`;

    //v12(Vry) , v23(Vyb), v31(Vbr)
    //I1(Ir), I2(Iy), I3(Ib)
    //Frequency - 0 to 5000
    //PF1, PF2, PF3
    // AVG pf - NO UNITS
    // TOTAL POWER (KW)  - 0 TO 250 KW
    // ENERGY CONSUMPTION (KWh)
    // * REACTIVE ENERGY CONSUMPTION (KVAh) - usefull for bill calculation only

    // 3 + 3 + 1 + 3 + 1 + 1 + 1 + 1
    // 14 parameters in total

    // Make a request to ThingsBoard
    const response = await axios.get(thingsBoardApiUrl, {
      headers: {
        Authorization: `Bearer ${tbToken}`,
      },
      params: {
        startTs: startTime,
        endTs: endTime,
        useStrictDataTypes: false,
        limit: userLimit,
        orderBy: "ASC",
      },
    });

    // console.log(response.data);

    // Return data to mobile
    res.status(200).json(response.data);
  } catch (error) {
    console.error("Error fetching data from ThingsBoard:", error.message);
    res.status(500).json({
      message: "Failed to fetch data from ThingsBoard",
      error: error.message,
    });
  }
};

// Get active status
exports.getDeviceActiveStatus = async (req, res) => {
  const { deviceId } = req.body;

  if (!deviceId) {
    return res.status(400).json({ message: "deviceId is required" });
  }

  const deviceDetails = await Machine.findById(deviceId).populate(
    "tbAccount",
    "name token"
  );

  // console.log(deviceDetails);

  try {
    const tbToken = deviceDetails.tbAccount.token;

    if (!tbToken) {
      return res
        .status(401)
        .json({ message: "Authorization token for ThingsBoard is missing" });
    }

    // https://thingsboard.cloud/api/plugins/telemetry/DEVICE/39faaa50-bb88-11ef-ae0e-b51a7d74c077/values/attributes

    // Construct the ThingsBoard API endpoint
    const thingsBoardApiUrl = `${TB_URL}/api/plugins/telemetry/DEVICE/${deviceDetails.deviceId}/values/attributes`;

    const response = await axios.get(thingsBoardApiUrl, {
      headers: {
        Authorization: `Bearer ${tbToken}`,
      },
    });
    // console.log(response.data);
    // Return data to mobile
    res.status(200).json(response.data);
  } catch (error) {
    console.error("Error fetching status from ThingsBoard:", error.message);
    res.status(500).json({
      message: "Failed to fetch status from ThingsBoard",
      error: error.message,
    });
  }
};

// Get live date
exports.getDataLive = async (req, res) => {
  const { deviceId } = req.body;

  if (!deviceId) {
    return res.status(400).json({ message: "deviceId is required" });
  }

  const deviceDetails = await Machine.findById(deviceId).populate(
    "tbAccount",
    "name token"
  );

  try {
    const tbToken = deviceDetails.tbAccount.token;

    if (!tbToken) {
      return res
        .status(401)
        .json({ message: "Authorization token for ThingsBoard is missing" });
    }

    // GET
    // /api/plugins/telemetry/{entityType}/{entityId}/values/timeseries{?keys,useStrictDataTypes}

    const thingsBoardApiUrl = `${TB_URL}/api/plugins/telemetry/DEVICE/${deviceDetails.deviceId}/values/timeseries?useStrictDataTypes=false`;

    const response = await axios.get(thingsBoardApiUrl, {
      headers: {
        Authorization: `Bearer ${tbToken}`,
      },
    });

    // console.log(response.data);

    res.status(200).json(response.data);
  } catch (error) {
    console.error("Error fetching live data from ThingsBoard:", error.message);
    res.status(500).json({
      message: "Failed to fetch live data from ThingsBoard",
      error: error.message,
    });
  }
};
