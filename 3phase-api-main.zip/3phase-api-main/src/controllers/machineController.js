const Machine = require("../models/Machine");

// Get all machines
exports.getAllMachines = async (req, res) => {
  try {
    const machines = await Machine.find()
      // .populate("device", "name") // Populate device with its name
      .populate("company", "name address"); // Populate company with its name
    res.status(200).json(machines);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get machine by ID
exports.getMachineById = async (req, res) => {
  try {
    const { machineId } = req.params;
    const machine = await Machine.findById(machineId)
      // .populate("device", "name")
      .populate("company", "name", "address");
    if (!machine) {
      return res.status(404).json({ message: "Machine not found" });
    }
    res.status(200).json(machine);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Create a new machine
exports.createMachine = async (req, res) => {
  try {
    const {
      name,
      make,
      model,
      std_current_rating,
      maximum_load,
      floating_current_R,
      floating_current_Y,
      floating_current_B,
      load_current_R,
      load_current_Y,
      load_current_B,
      device,
      company,
    } = req.body;

    const image = req.file ? req.file.filename : null;

    const newMachine = await Machine.create({
      name,
      make,
      model,
      std_current_rating,
      maximum_load,
      floating_current_R,
      floating_current_Y,
      floating_current_B,
      load_current_R,
      load_current_Y,
      load_current_B,
      device,
      company,
      image,
    });

    res
      .status(201)
      .json({ message: "Machine created successfully", machine: newMachine });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Update machine
exports.updateMachine = async (req, res) => {
  try {
    const { machineId } = req.params;
    const {
      name,
      label,
      deviceId,
      token,
      make,
      model,
      std_current_rating,
      maximum_load,
      floating_current_R,
      floating_current_Y,
      floating_current_B,
      load_current_R,
      load_current_Y,
      load_current_B,
      device,
      company,
      isActive,
    } = req.body;

    const image = req.file ? req.file.filename : null;

    const updatedMachine = await Machine.findByIdAndUpdate(
      machineId,
      {
        name,
        label,
        deviceId,
        token,
        make,
        model,
        std_current_rating,
        maximum_load,
        floating_current_R,
        floating_current_Y,
        floating_current_B,
        load_current_R,
        load_current_Y,
        load_current_B,
        device,
        company,
        image,
        isActive,
      },
      { new: true, runValidators: true }
    );

    if (!updatedMachine) {
      return res.status(404).json({ message: "Machine not found" });
    }

    res.status(200).json({
      message: "Machine updated successfully",
      machine: updatedMachine,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Delete machine
exports.deleteMachine = async (req, res) => {
  try {
    const { machineId } = req.params;

    const deletedMachine = await Machine.findByIdAndDelete(machineId);
    if (!deletedMachine) {
      return res.status(404).json({ message: "Machine not found" });
    }

    res.status(200).json({ message: "Machine deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};
