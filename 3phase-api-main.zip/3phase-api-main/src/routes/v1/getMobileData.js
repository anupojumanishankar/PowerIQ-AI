const express = require("express");
const {
  getDataTimeSeries,
  getDeviceActiveStatus,
  getDataLive,
} = require("../../controllers/getMobileDataController");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
// const upload = require("../../middlewares/upload");
const router = express.Router();
const axios = require("axios");

router.get("/", (req, res) => {
  res.status(200).json({
    message: "Welcome to TB Proxy",
  });
});

// Route to fetch data from ThingsBoard

router.post("/active", authenticateToken, getDeviceActiveStatus);

router.post("/dataTs", authenticateToken, getDataTimeSeries);

router.post("/dataLive", authenticateToken, getDataLive);

module.exports = router;
