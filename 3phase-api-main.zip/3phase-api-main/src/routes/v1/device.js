const express = require("express");
const {
  getAllDevices,
  createDevice,
  getDeviceById,
  getDeviceByIdESP,
  updateDevice,
  deleteDevice,
  getAllMyCompanyDevices,
  linkDeviceWithCompany,
} = require("../../controllers/deviceController");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
const upload = require("../../middlewares/upload");
const checkManager = require("../../middlewares/checkManager");
const router = express.Router();

router.get("/", authenticateToken, checkAdmin, getAllDevices);

router.get(
  "/my-devices",
  authenticateToken,
  checkManager,
  getAllMyCompanyDevices
);

router.post("/link", authenticateToken, checkManager, linkDeviceWithCompany);

router.post(
  "/",
  authenticateToken,
  // checkManager,
  // checkAdmin,
  upload.single("image"),
  createDevice
);
router.get("/:deviceId", authenticateToken, getDeviceById);
router.get("/embed/:deviceId", getDeviceByIdESP);
router.put(
  "/:deviceId",
  authenticateToken,
  // checkAdmin,
  upload.single("image"),
  updateDevice
);
router.delete("/:deviceId", authenticateToken, checkAdmin, deleteDevice);

module.exports = router;
