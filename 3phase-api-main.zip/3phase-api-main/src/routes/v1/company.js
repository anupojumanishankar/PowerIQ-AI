const express = require("express");
const {
  getAllCompanies,
  createCompany,
  getCompanyById,
  getMyCompany,
  updateCompany,
  deleteCompany,
  updateMyCompany,
} = require("../../controllers/companyController");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
const upload = require("../../middlewares/upload");
const checkManager = require("../../middlewares/checkManager");
const router = express.Router();

router.get("/", authenticateToken, checkAdmin, getAllCompanies);
router.get("/my", authenticateToken, checkManager, getMyCompany);
router.post("/", upload.single("image"), createCompany);

// authenticateToken, checkAdmin,

router.get("/:companyId", authenticateToken, checkAdmin, getCompanyById);

router.put("/my", authenticateToken, upload.single("image"), updateMyCompany);

router.put(
  "/:companyId",
  authenticateToken,
  upload.single("image"),
  updateCompany
);

router.delete("/:companyId", authenticateToken, checkAdmin, deleteCompany);

module.exports = router;
