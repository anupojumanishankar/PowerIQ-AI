const express = require("express");
const {
  getAllPages,
  createPage,
  getPageById,
  updatePage,
  deletePage,
} = require("../../controllers/pageController");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
const upload = require("../../middlewares/upload");
const checkManager = require("../../middlewares/checkManager");
const router = express.Router();

router.get("/", authenticateToken, getAllPages);

router.post("/", authenticateToken, createPage);

router.get("/:pageId", authenticateToken, getPageById);

router.put("/:pageId", authenticateToken, updatePage);

router.delete("/:pageId", authenticateToken, deletePage);

module.exports = router;
