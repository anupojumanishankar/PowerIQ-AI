const express = require("express");
const authenticateToken = require("../../middlewares/auth");
const router = express.Router();
const ThingsBoardAccount = require("../../models/Thingsboard");

// API to Get List of All ThingsBoard Accounts (_id and username only)
router.get("/", authenticateToken, async (req, res) => {
  try {
    const accounts = await ThingsBoardAccount.find({}, "_id name"); // Fetch only _id and username
    res.status(200).json(accounts);
  } catch (error) {
    console.error("Error fetching accounts:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

module.exports = router;
