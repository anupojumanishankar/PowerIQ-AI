// notificationRoutes.js
const express = require("express");
const {
  getAllNotifications,
  addNotification,
  markNotificationAsRead,
  getAllNotificationsByDeviceId,
  tbAddNotification,
} = require("../../controllers/notificationController");
const authenticateToken = require("../../middlewares/auth");
const staticTokenAuth = require("../../middlewares/staticTokenAuth");

const router = express.Router();

// Get all notifications for the current user
router.get("/", authenticateToken, getAllNotifications);

// Get all notifications for the current user by deviceId
router.get("/:deviceId", authenticateToken, getAllNotificationsByDeviceId);

// Add a new notification
router.post("/", authenticateToken, addNotification);

// Add a new notification
router.post("/tb", staticTokenAuth, tbAddNotification);

// Mark a notification as read
router.put("/:notificationId", authenticateToken, markNotificationAsRead);

module.exports = router;
