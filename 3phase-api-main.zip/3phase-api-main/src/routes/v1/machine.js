const express = require("express");
const {
  getAllMachines,
  createMachine,
  getMachineById,
  updateMachine,
  deleteMachine,
} = require("../../controllers/machineController");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
const upload = require("../../middlewares/upload");
const router = express.Router();

// Get all machines
router.get("/", authenticateToken, checkAdmin, getAllMachines);

// // Create a new machine
// router.post(
//   "/",
//   authenticateToken,
//   checkAdmin,
//   upload.single("image"),
//   createMachine
// );

// Get a specific machine by ID
router.get("/:machineId", authenticateToken, checkAdmin, getMachineById);

// Update a specific machine
router.put(
  "/:machineId",
  authenticateToken,
  checkAdmin,
  upload.single("image"),
  updateMachine
);

// Delete a specific machine
router.delete("/:machineId", authenticateToken, checkAdmin, deleteMachine);

module.exports = router;
