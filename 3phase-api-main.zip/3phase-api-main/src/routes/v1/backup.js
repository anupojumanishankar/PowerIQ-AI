const express = require("express");
const { exec } = require("child_process");
const path = require("path");
const fs = require("fs");

const router = express.Router();

// Backup directory path
const backupDir = path.resolve(__dirname, "../../../../backup-db");

// API to list all backups
router.get("/backups", async (req, res) => {
  try {
    // Ensure the backup directory exists
    if (!fs.existsSync(backupDir)) {
      return res
        .status(404)
        .json({ message: "Backup directory does not exist" });
    }

    // Read all files in the backup directory
    const files = fs.readdirSync(backupDir);

    // Filter only backup files (optional: based on naming convention)
    const backups = files
      .filter((file) => file.startsWith("backup-")) // && file.endsWith(".gz"))
      .map((file) => ({
        filename: file,
        path: path.join(backupDir, file), // Absolute path
        timestamp: fs.statSync(path.join(backupDir, file)).mtime, // Last modified time
      }));

    if (backups.length === 0) {
      return res.status(404).json({ message: "No backups found" });
    }

    // Respond with the list of backups
    res.status(200).json({ backups });
  } catch (error) {
    console.error("Error listing backups:", error);
    res
      .status(500)
      .json({ message: "Error retrieving backups", error: error.message });
  }
});

// Backup MongoDB
router.post("/backup", (req, res) => {
  const backupFolder = path.join(__dirname, "../../../../backup-db");
  if (!fs.existsSync(backupFolder)) {
    fs.mkdirSync(backupFolder, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupFile = path.join(backupFolder, `backup-${timestamp}`);

  const command = `mongodump --uri="${process.env.MONGO_URI}" --out=${backupFile}`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Backup error: ${error.message}`);
      return res
        .status(500)
        .json({ message: "Backup failed", error: error.message });
    }

    console.log(`Backup created at: ${backupFile}`);
    res.status(200).json({ message: "Backup successful", backupFile });
  });
});

// Restore MongoDB
router.post("/restore", (req, res) => {
  const { fileName } = req.body;
  if (!fileName) {
    return res.status(400).json({ message: "File name is required" });
  }

  const backupFolder = path.join(__dirname, "../../../../backup-db");
  const restorePath = path.join(backupFolder, fileName);

  if (!fs.existsSync(restorePath)) {
    return res.status(404).json({ message: "Backup file not found" });
  }

  const command = `mongorestore --uri="${process.env.MONGO_URI}" --dir=${restorePath}`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Restore error: ${error.message}`);
      return res
        .status(500)
        .json({ message: "Restore failed", error: error.message });
    }

    console.log(`Database restored from: ${restorePath}`);
    res.status(200).json({ message: "Restore successful" });
  });
});

module.exports = router;
