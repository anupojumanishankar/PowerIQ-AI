const express = require("express");
const router = express.Router();
const DeviceIot = require("../../models/DeviceIot");
const authenticateToken = require("../../middlewares/auth");
const checkAdmin = require("../../middlewares/checkAdmin");
const crypto = require("crypto");

const generateToken = () => crypto.randomBytes(16).toString("hex");

router.get("/", authenticateToken, checkAdmin, async (req, res) => {
  try {
    const devices = await DeviceIot.find().populate(
      "userId",
      "name email role"
    );
    res.status(200).json(devices);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
});

router.delete("/:deviceId", authenticateToken, checkAdmin, async (req, res) => {
  try {
    const { deviceId } = req.params;

    const deletedDevice = await DeviceIot.findByIdAndDelete(deviceId);
    if (!deletedDevice) {
      return res.status(404).json({ message: "Device not found" });
    }

    res.status(200).json({ message: "Device deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
});

router.post("/register", authenticateToken, async (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "Device name is required." });
  }

  try {
    // Create a new device
    const token = generateToken();
    const newDevice = new DeviceIot({
      name,
      token,
      userId: req.user.id,
    });

    await newDevice.save();
    res.status(201).json({ message: "Device registered successfully", token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error registering device." });
  }
});

module.exports = router;
