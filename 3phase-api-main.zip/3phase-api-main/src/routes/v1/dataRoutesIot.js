const express = require("express");
const { storeData, getData } = require("../../controllers/dataControllerIot");
const router = express.Router();
const mqttClient = require("../../services/mqttIot");
const authenticateToken = require("../../middlewares/auth");
const DeviceIot = require("../../models/DeviceIot");

router.post("/", authenticateToken, storeData);
router.get("/:deviceId", authenticateToken, getData);

// Send data to a device via MQTT
router.post("/send", authenticateToken, async (req, res) => {
  const { deviceId, payload } = req.body;

  if (!deviceId || !payload) {
    return res
      .status(400)
      .json({ message: "Device ID and payload are required." });
  }

  try {
    // Find the device
    const device = await DeviceIot.findById(deviceId);
    if (!device) {
      return res.status(404).json({ message: "Device not found." });
    }

    // Define topic (e.g., device-specific topic)
    const topic = `devices/${device.token}/data`;

    // Publish payload to the device topic
    mqttClient.publish(topic, JSON.stringify(payload), (err) => {
      if (err) {
        return res
          .status(500)
          .json({ message: "Failed to send data via MQTT." });
      }
      res.status(200).json({ message: "Data sent to device successfully." });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error sending data to device." });
  }
});

module.exports = router;
