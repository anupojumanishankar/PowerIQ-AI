require("dotenv").config(); // Load environment variables
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bodyParser = require("body-parser");
const path = require("path");
const { Server } = require("socket.io");
const http = require("http");
const jwt = require("jsonwebtoken");

// Import custom modules
const cors = require("./config/cors");
const connectDB = require("./config/db");
const errorHandler = require("./middlewares/errorHandler");
const startMQTT = require("./config/mqttIot");

// Import route handlers
const authRoutes = require("./routes/v1/auth");
const userRoutes = require("./routes/v1/user");
const companyRoutes = require("./routes/v1/company");
const deviceRoutes = require("./routes/v1/device");
const machineRoutes = require("./routes/v1/machine");
const getMobileDataRoutes = require("./routes/v1/getMobileData");
const backupRoutes = require("./routes/v1/backup");
const notificationRoutes = require("./routes/v1/notificationRoutes");
const dataRoutesIot = require("./routes/v1/dataRoutesIot");
const deviceRoutesIot = require("./routes/v1/deviceRoutesIot");
// const tbAccountRoutes = require("./routes/v1/tbAccount");

const pageRoutes = require("./routes/v1/page");

const disk = require("diskusage"); // For disk storage usage
const os = require("os"); // To get disk root path
const osUtils = require("os-utils");

const { updateTokensForAllAccounts } = require("./services/thingsBoardService");
const cron = require("node-cron");

// Initialize database and MQTT connection
connectDB();
startMQTT();

// Initialize Express app
const app = express();
const server = http.createServer(app); // Create HTTP server
const io = new Server(server, {
  cors: {
    origin: process.env.CORS_WHITELIST
      ? process.env.CORS_WHITELIST.split(",")
      : "*",
    methods: ["GET", "POST", "PUT", "DELETE"],
  },
});

// Rate limiting middleware
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // Limit each IP to 100 requests per windowMs
  keyGenerator: (req) => req.ip, // Use correct IP
  message: "Too many requests, please try again later.",
});

// Apply global middlewares
app.set("trust proxy", 1); // Trust first proxy
app.use(limiter);
app.use(helmet());
app.use(bodyParser.json());
app.use(
  "/uploads",
  cors,
  express.static(path.join(__dirname, "../../uploads"))
);
app.use(cors);

// Attach `io` to requests
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Status Monitoring Endpoint
app.get("/api/v1/status", async (req, res) => {
  const hardcodedToken = "dr34vv4v4eRTEt34rt_sedf-eferr4"; // Replace with your secure token

  // Extract token from request headers
  const clientToken = req.headers["x-api-key"]; // Use a custom header like 'x-api-key'

  // Validate the token
  // if (!clientToken || clientToken !== hardcodedToken) {
  //   return res.status(401).json({
  //     status: "error",
  //     message: "Unauthorized. Invalid or missing token.",
  //   });
  // }

  try {
    // Get disk usage
    const diskInfo = await disk.check(os.platform() === "win32" ? "C:" : "/");
    const freeDiskPercentage = ((diskInfo.free / diskInfo.total) * 100).toFixed(
      2
    );

    // Get memory usage
    const totalMemory = os.totalmem(); // in bytes
    const freeMemory = os.freemem(); // in bytes
    const usedMemoryPercentage = (
      ((totalMemory - freeMemory) / totalMemory) *
      100
    ).toFixed(2);
    const freeMemoryPercentage = ((freeMemory / totalMemory) * 100).toFixed(2);

    // Get CPU usage
    osUtils.cpuUsage((cpuPercentage) => {
      const status = {
        status: "online",
        uptime: (process.uptime() / 3600).toFixed(2), // + " hours", // Uptime in hours
        timestamp: new Date().toISOString(),
        disk: {
          total: (diskInfo.total / (1024 * 1024 * 1024)).toFixed(2) + " GB",
          free: (diskInfo.free / (1024 * 1024 * 1024)).toFixed(2) + " GB",
          usedPercentage: 100 - freeDiskPercentage + "%", // Used disk space in percentage
          freePercentage: freeDiskPercentage + "%", // Free disk space in percentage
        },
        memory: {
          total: (totalMemory / (1024 * 1024 * 1024)).toFixed(2) + " GB",
          free: (freeMemory / (1024 * 1024 * 1024)).toFixed(2) + " GB",
          usedPercentage: usedMemoryPercentage + "%", // Used memory in percentage
          freePercentage: freeMemoryPercentage + "%", // Free memory in percentage
        },
        cpu: {
          usage: (cpuPercentage * 100).toFixed(2) + "%", // CPU usage in percentage
        },
      };

      res.status(200).json(status);
    });
  } catch (error) {
    console.error("Error retrieving system status:", error.message);
    res.status(500).json({
      status: "error",
      message: "Unable to retrieve system status.",
    });
  }
});

// Define default routes
app.get("/", (req, res) => {
  res.status(200).json({
    message: "Welcome to the API",
    endpoints: {
      v1: "/api/v1/",
    },
  });
});

// echo start
const admin = require("firebase-admin");
const mongoose = require("mongoose");
// Initialize Firebase Admin SDK
const serviceAccount = require("../firebase-service-account.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// Define Schema
const echoSchema = new mongoose.Schema({ data: Object }, { timestamps: true });
const Echo = mongoose.model("Echo", echoSchema);

const { sendFCMNotification } = require("./services/notificationService");

// API to save data and send notification
app.post("/echo", async (req, res) => {
  try {
    // const { data, fcmToken } = req.body;

    // if (!data || !fcmToken) {
    //   return res.status(400).json({ error: "Missing data or fcmToken" });
    // }

    // Save data to MongoDB
    const echoData = new Echo({ data: req.body });
    await echoData.save();

    // Send Firebase notification
    await sendFCMNotification(
      "dKca3HqnR9iIQNP0KmSkKK:APA91bHnJw6I7qXGhGcibAWQRVr5WR2Khr0loabJkSG1lzIwanE4qwMFhw8UjxdQH6YuFaN0c2x_YqQ4skbDrrQIRmb_Avvf1y9fJ5wyavv_cVT9Ym8j298", // fcmToken,
      "New Echo Data",
      "Check your latest update!"
    );

    res
      .status(201)
      .json({ message: "Data saved & notification sent", data: echoData });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// // POST /echo - Store received object
// app.post("/echo", async (req, res) => {
//   try {
//     const echoData = new Echo({ data: req.body });
//     await echoData.save();

//     console.log(echoData);

//     // Emit notification to the specific room
//     const roomId = "677faf7f6e0515f1db968fa2";
//     io.to(roomId).emit("newNotification", {
//       message: "New data received",
//       data: echoData,
//     });

//     res.status(201).json({ message: "Data saved", data: echoData });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// GET /echo - Retrieve all stored objects
app.get("/echo", async (req, res) => {
  try {
    const allData = await Echo.find().sort({ createdAt: -1 });
    res.json(allData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// echo end

app.get("/api/v1/", (req, res) => {
  res.status(200).json({
    message: "Welcome to the API v1",
    endpoints: {
      auth: "/api/v1/auth",
      user: "/api/v1/user",
      company: "/api/v1/company",
      page: "/api/v1/page",
      device: "/api/v1/device",
      machine: "/api/v1/machine",
      getMobileData: "/api/v1/getMobileData",
      backup: "/api/v1/backup",
      notification: "/api/v1/notification",
      iotdata: "/api/v1/iotdata",
      iotdevice: "/api/v1/iotdevice",
      page: "/api/v1/page",
      tb: "/api/v1/tb",
    },
  });
});

// Mount API routes
app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/user", userRoutes);
app.use("/api/v1/company", companyRoutes);
app.use("/api/v1/device", deviceRoutes);
app.use("/api/v1/machine", machineRoutes);
app.use("/api/v1/getMobileData", getMobileDataRoutes);
app.use("/api/v1/backup", backupRoutes);
app.use("/api/v1/notification", notificationRoutes);

app.use("/api/v1/page", pageRoutes);
// app.use("/api/v1/tb", tbAccountRoutes);

app.use("/api/v1/iotdata", dataRoutesIot);
app.use("/api/v1/iotdevice", deviceRoutesIot);

// Handle errors
app.use(errorHandler);

// Set production environment
if (process.env.NODE_ENV === "production") {
  app.set("env", "production");
}

// Socket.IO event handling
io.on("connection", (socket) => {
  console.log("Socket connected:", socket.id);

  // Handle user joining a room
  socket.on("join", (userId) => {
    if (userId) {
      socket.join(userId.toString());
      console.log(`User ${userId} joined room ${userId}`);
    } else {
      console.log("join event received without userId");
    }
  });

  // Authenticate user via JWT
  socket.on("authenticate", (token) => {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET); // Ensure JWT_SECRET is set
      socket.join(decoded.id); // Use user ID as room
      socket.emit("authenticated", { success: true, userId: decoded.id });
      socket.emit("newNotification", { success: true, userId: decoded.role });
    } catch (err) {
      console.error("Authentication failed:", err.message);
      socket.emit("authenticated", {
        success: false,
        message: "Invalid token",
      });
      socket.disconnect();
    }
  });

  // Handle custom messages
  socket.on("message", (data) => {
    console.log("Message received:", data);
    socket.broadcast.emit("message", data);
  });

  // Handle disconnection
  socket.on("disconnect", () => {
    console.log("Socket disconnected:", socket.id);
  });
});

// // Update Tokens Periodically (every 2 hours)
// cron.schedule("0 */2 * * *", async () => {
//   console.log(Date(), "Updating tokens...");
//   await updateTokensForAllAccounts(); // Use the service to update tokens for all accounts
// });

// // Update Tokens on Server Restart
// (async () => {
//   console.log(Date(), "Updating tokens on server restart...");
//   await updateTokensForAllAccounts(); // Use the service to update tokens for all accounts
// })();

// Start the server
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || "0.0.0.0";
server.listen(PORT, HOST, () => {
  console.log(`Server running on port ${PORT}`);
});

// Export app and server for testing or future use
module.exports = { app, server, io };
