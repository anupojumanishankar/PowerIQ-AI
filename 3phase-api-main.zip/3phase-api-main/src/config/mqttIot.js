const aedes = require("aedes")();
const net = require("net");

const mqttServer = net.createServer(aedes.handle);

const startMQTT = (port = process.env.MQTT_PORT || 1883) => {
  mqttServer.listen(port, () => {
    console.log(`MQTT Broker running on port ${port}`);
  });

  aedes.on("client", (client) => {
    // console.log(`Client connected: ${client.id}`);
  });

  aedes.on("publish", async (packet, client) => {
    if (client) {
      // console.log(`Message from ${client.id}: ${packet.payload.toString()}`);
    }
  });
};

module.exports = startMQTT;
