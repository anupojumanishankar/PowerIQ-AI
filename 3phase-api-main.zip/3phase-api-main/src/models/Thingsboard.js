const mongoose = require("mongoose");

const thingsBoardAccountSchema = new mongoose.Schema(
  {
    username: String,
    password: String, // Store encrypted if possible
    token: String,
    refreshToken: String,
    lastUpdated: { type: Date, default: Date.now }, // When tokens were last updated
  },
  {
    timestamps: true,
  }
);

const ThingsBoardAccount = mongoose.model(
  "ThingsBoardAccount",
  thingsBoardAccountSchema
);

module.exports = ThingsBoardAccount;
