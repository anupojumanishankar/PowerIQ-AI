const mongoose = require("mongoose");

const deviceSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    label: {
      type: String,
      default: null,
    },
    deviceId: {
      type: String,
      default: null,
    },
    token: {
      type: String,
      default: null,
    },
    image: {
      type: String,
      default: null,
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
      // required: true,
      required: false,
      // required: function () {
      //   return this.role !== "admin";
      // },
    },
    machine: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Machine",
      // required: true,
      required: false,
      // required: function () {
      //   return this.role !== "admin";
      // },
    },
    data_interval: {
      type: Number,
      default: null,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

const Device = mongoose.model("Device", deviceSchema);

module.exports = Device;
