const mongoose = require("mongoose");

const DataIotSchema = new mongoose.Schema({
  deviceId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "DeviceIot",
    required: true,
  },
  data: { type: Object, required: true },
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model("DataIot", DataIotSchema);
