const mongoose = require("mongoose");

const machineSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: false,
      trim: true,
    },

    make: {
      type: String,
      default: null,
    },

    model: {
      type: String,
      default: null,
    },

    std_current_rating: {
      type: String,
      default: null,
    },

    maximum_load: {
      type: String,
      default: null,
    },

    floating_current_R: {
      type: String,
      default: null,
    },
    floating_current_Y: {
      type: String,
      default: null,
    },
    floating_current_B: {
      type: String,
      default: null,
    },

    load_current_R: {
      type: String,
      default: null,
    },
    load_current_Y: {
      type: String,
      default: null,
    },
    load_current_B: {
      type: String,
      default: null,
    },

    // device: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "Device",
    //   // required: true,
    //   required: false,
    //   // required: function () {
    //   //   return this.role !== "admin";
    //   // },
    // },

    image: {
      type: String,
      default: null,
    },

    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
      // required: true,
      required: false,
      // required: function () {
      //   return this.role !== "admin";
      // },
    },

    isActive: {
      type: Boolean,
      default: false,
    },

    isPaymentDelay: {
      type: Boolean,
      default: false,
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },

    data_interval: {
      type: String,
      default: null,
    },

    token: {
      type: String,
      default: null,
    },

    deviceId: {
      type: String,
      default: null,
    },

    label: {
      type: String,
      default: null,
    },

    tbAccount: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ThingsBoardAccount",
      // required: true,
      required: false,
      // required: function () {
      //   return this.role !== "admin";
      // },
    },
  },
  { timestamps: true }
);

const Machine = mongoose.model("Machine", machineSchema);

module.exports = Machine;
