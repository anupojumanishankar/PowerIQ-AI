const mqtt = require("mqtt");
const mongoose = require("mongoose");
const DataIot = require("../models/DataIot"); // Import your Data model
const DeviceIot = require("../models/DeviceIot"); // Import Device model if needed to reference the device

const brokerUrl = process.env.MQTT_BROKER_URL || "mqtt://localhost:1883";
const mqttClient = mqtt.connect(brokerUrl);

// Event: MQTT Connected
mqttClient.on("connect", () => {
  console.log(`Connected to MQTT broker at ${brokerUrl}`);

  // Subscribe to device-specific data topics
  const topic = "devices/+/data"; // Wildcard to listen to all device data topics
  mqttClient.subscribe(topic, (err) => {
    if (err) {
      console.error("Failed to subscribe to topic:", err);
    } else {
      //   console.log(`Subscribed to topic: ${topic}`);
    }
  });
});

// Event: Message Received
mqttClient.on("message", async (topic, message) => {
  //   console.log(`Message received on topic ${topic}: ${message.toString()}`);

  try {
    // Extract the device token from the topic (e.g., 'device123')
    const deviceToken = topic.split("/")[1]; // Get the token part of the topic

    // Parse the payload (assuming it's JSON)
    const payload = JSON.parse(message.toString());

    // Find the device by its token (if needed)
    const device = await DeviceIot.findOne({ token: deviceToken });
    if (!device) {
      console.error("Device not found:", deviceToken);
      return;
    }

    // Create a new Data document to store in MongoDB
    const data = new DataIot({
      deviceId: device._id, // Store the reference to the device
      data: payload, // The actual data payload from the message
      timestamp: new Date(), // Current timestamp
    });

    // Save the data to the database
    await data.save();
    // console.log("Data saved to MongoDB:", data);
  } catch (err) {
    console.error("Error processing MQTT message:", err);
  }
});

module.exports = mqttClient;
