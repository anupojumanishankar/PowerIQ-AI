const admin = require("firebase-admin");

// Function to send FCM notification
async function sendFCMNotification(fcmToken, title, body) {
  try {
    const message = {
      token: fcmToken,
      notification: { title, body },
      android: {
        priority: "high",
        notification: {
          sound: "default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
          },
        },
      },
    };

    await admin.messaging().send(message);
    console.log("✅ Notification sent successfully");
  } catch (error) {
    console.error("❌ Error sending notification:", error);
  }
}

module.exports = {
  sendFCMNotification,
};
