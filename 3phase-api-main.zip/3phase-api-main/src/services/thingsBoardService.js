const axios = require("axios");
const ThingsBoardAccount = require("../models/Thingsboard");

// Function to get ThingsBoard Token
async function getThingsBoardToken(username, password) {
  try {
    const response = await axios.post(`${process.env.TB_URL}/api/auth/login`, {
      username,
      password,
    });

    const { token, refreshToken } = response.data;
    return { token, refreshToken };
  } catch (error) {
    console.error(Date(), "Error getting token from ThingsBoard:", error);
    return null;
  }
}

// Function to update tokens for all accounts
async function updateTokensForAllAccounts() {
  const accounts = await ThingsBoardAccount.find(); // Get all accounts

  for (const account of accounts) {
    const { username, password } = account;
    const tokens = await getThingsBoardToken(username, password);

    if (tokens) {
      await ThingsBoardAccount.updateOne(
        { _id: account._id },
        {
          $set: {
            token: tokens.token,
            refreshToken: tokens.refreshToken,
            lastUpdated: new Date(),
          },
        }
      );
      console.log(`${Date()} Updated token for account: ${username}`);
    }
  }
}

module.exports = {
  getThingsBoardToken,
  updateTokensForAllAccounts,
};
