module.exports = {
  apps: [
    {
      name: "3phase-api", // Application name
      script: "./src/app.js", // Main entry point
      instances: "max", // Launch as many instances as there are CPU cores
      exec_mode: "cluster", // Enable cluster mode for load balancing
      watch: false, // Disable file watching (set true only for development)
      env: {
        NODE_ENV: "development", // Default environment
        PORT: 9610, // Default port for development
      },
      env_development: {
        NODE_ENV: "development",
        PORT: 9610,
      },
      env_production: {
        NODE_ENV: "production",
        PORT: 9610,
      },
    },
  ],
};
